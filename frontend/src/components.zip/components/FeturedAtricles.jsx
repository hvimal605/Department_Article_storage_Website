const FeaturedArticles = () => {
    // Replace with dynamic data
    const articles = [
      {
        title: "Advances in AI Research",
        author: "Harshi",
        date: "Oct 15, 2024",
        abstract: "An exploration of the latest trends in artificial intelligence.",
      },
      {
        title: "Quantum Computing: The Future of Tech",
        author: "harsh",
        date: "Sep 22, 2024",
        abstract: "A deep dive into the potential of quantum computing.",
      },
      {
        title: "Renewable Energy Solutions",
        author: "Ojha",
        date: "Aug 10, 2024",
        abstract: "Innovative approaches to harnessing renewable energy.",
      },
      {
        title: "Cybersecurity in the Modern Age",
        author: "Vimal",
        date: "Jul 5, 2024",
        abstract: "Challenges and solutions in today's cybersecurity landscape.",
      },
      {
        title: "AI Ethics and Society",
        author: "Harshit Ojha",
        date: "Jun 18, 2024",
        abstract: "Exploring the ethical implications of AI development.",
      },
      {
        title: "Climate Change and Global Policy",
        author: "Harsh Vimal",
        date: "May 22, 2024",
        abstract: "A look at international efforts to combat climate change.",
      },
    ];
  
    return (
      <section className="py-16 border-2 bg-gradient-to-b from-white to-gray-100 relative">
        <div className="absolute inset-0 opacity-50">
          <img
            src="https://thumbs.wbm.im/pw/small/944b0f658596e157096c4714df6f790e.jpg"
            alt="Books"
            className="w-full h-full "
          />
        </div>
        <div className="absolute inset-0 opacity-50 bg-black ">
         
        </div>
        <div className="container mx-auto px-6 relative z-10">
          <h2 className="text-4xl font-bold text-white text-center mb-12">
            Recent Articles
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
            {articles.map((article, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-xl shadow-lg hover:shadow-2xl transform transition-all duration-300 hover:scale-105"
              >
                {/* Article Title */}
                <h3 className="text-xl font-bold text-gray-900 mb-2">{article.title}</h3>
                {/* Author */}
                <p className="text-gray-700">By {article.author}</p>
                {/* Date */}
                <p className="text-gray-500 text-sm">{article.date}</p>
                {/* Abstract */}
                <p className="mt-4 text-gray-600">{article.abstract}</p>
                {/* View Button */}
                <button className="mt-6 inline-block px-5 py-2 bg-blue-600 text-white font-semibold rounded-full hover:bg-blue-700 transition-colors">
                  View Article
                </button>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  };
  
  export default FeaturedArticles;
  