const PlatformFeaturesSection = () => {
    return (
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-gray-800 mb-12">
            Powerful Platform Features
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-12">
            {/* Feature 1 */}
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow transform hover:-translate-y-2 duration-300">
              <div className="mb-4 text-green-600 text-4xl">
                <i className="fas fa-book"></i> {/* You can replace this with any relevant icon */}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                Department-Wide Article Repository
              </h3>
              <p className="text-gray-600">
                A centralized platform to store and access research articles from across the department, ensuring seamless collaboration and sharing.
              </p>
            </div>
            {/* Feature 2 */}
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow transform hover:-translate-y-2 duration-300">
              <div className="mb-4 text-blue-600 text-4xl">
                <i className="fas fa-cloud"></i> {/* Cloud icon */}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                Secure, Cloud-Based Storage
              </h3>
              <p className="text-gray-600">
                Ensure that all research articles are securely stored in the cloud, with options for version control and easy retrieval.
              </p>
            </div>
            {/* Feature 3 */}
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow transform hover:-translate-y-2 duration-300">
              <div className="mb-4 text-orange-500 text-4xl">
                <i className="fas fa-upload"></i> {/* Upload icon */}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                Seamless Article Upload
              </h3>
              <p className="text-gray-600">
                Quickly upload research articles, assign authors, and add metadata like keywords, topics, and publication details.
              </p>
            </div>
            {/* Feature 4 */}
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow transform hover:-translate-y-2 duration-300">
              <div className="mb-4 text-purple-500 text-4xl">
                <i className="fas fa-search"></i> {/* Search icon */}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                Advanced Search and Filter Options
              </h3>
              <p className="text-gray-600">
                Easily find specific research papers using advanced search filters based on keywords, authors, or categories.
              </p>
            </div>
            {/* Feature 5 */}
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow transform hover:-translate-y-2 duration-300">
              <div className="mb-4 text-red-500 text-4xl">
                <i className="fas fa-chart-line"></i> {/* Analytics icon */}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                Citation and Analytics Tracking
              </h3>
              <p className="text-gray-600">
                Track article views, downloads, and citations, giving authors detailed insights into their research impact.
              </p>
            </div>
            {/* Feature 6 */}
            <div className="bg-white p-8 rounded-lg shadow-md hover:shadow-xl transition-shadow transform hover:-translate-y-2 duration-300">
              <div className="mb-4 text-yellow-500 text-4xl">
                <i className="fas fa-users"></i> {/* Collaboration icon */}
              </div>
              <h3 className="text-xl font-semibold text-gray-800 mb-4">
                Collaborative Research Workflows
              </h3>
              <p className="text-gray-600">
                Allow co-authors to collaborate easily by adding and managing access to shared research projects.
              </p>
            </div>
          </div>
        </div>
      </section>
    );
  };
  
  export default PlatformFeaturesSection;
  