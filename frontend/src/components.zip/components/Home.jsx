import PlatformFeaturesSection from "./BenefitSection";
import BenefitsSection from "./BenefitSection";
import FeaturedArticles from "./FeturedAtricles";
import Footer from "./Footer";
import HeroSection from "./HeroSection";
import NewsletterSignup from "./NewsletterSignup";
import UploadArticleSection from "./UploadArticleSection";

const HomePage = () => {
    return (
      <div>
        {/* Hero Section */}
        <HeroSection />
  
        {/* Featured Articles Section */}
        <FeaturedArticles />
  
        {/* Benefits Section */}
        <PlatformFeaturesSection />

        <UploadArticleSection/>
  
        {/* Newsletter Signup */}
        <NewsletterSignup />
  
        {/* Footer */}
        <Footer />
      </div>
    );
  };
  
  export default HomePage;
  